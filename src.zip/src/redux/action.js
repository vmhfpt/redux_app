
export const addTodo = (data) => {
    return {
        type : "addTodo",
        payload : data
    }
}